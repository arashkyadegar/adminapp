

export default function CategoryListComponent() {
     return (<h1>CategoryListComponent</h1>);
}