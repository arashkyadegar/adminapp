export default function BoxTitleComponent({ title }: any) {
     return (
          <h1 className="font-bold text-sm text-gray-500 p-2">{title}</h1>
     )
}