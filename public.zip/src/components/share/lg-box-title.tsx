export default function BoxTitleLgComponent({ title }: any) {
     return (
          <h1 className="font-bold text-lg text-black p-2">{title}</h1>
     )
}