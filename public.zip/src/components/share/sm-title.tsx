export default function SmTitleComponent({ title }: any) {
     return (
          <h1 className="font-bold text-xs text-gray-400 py-2">{title}</h1>
     )
}