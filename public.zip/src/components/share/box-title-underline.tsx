export default function BoxTitleUnderlineComponent({ title }: any) {
     return (
          <h1 className="font-bold text-sm text-gray-500 p-4 border-b border-gray-200">{title}</h1>
     )
}